const WorldCreationApp = () => {
  return (
    <div className="h-screen bg-gray-900 text-white">
      {/* Navbar */}
      <nav className="fixed w-full top-0 px-4 py-3 backdrop-blur-sm border-b border-gray-700">
        <div className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
          WorldCreation
        </div>
        <div className="hidden md:flex space-x-4">
          <a href="#accueil" className="hover:text-indigo-400 transition-colors">Accueil</a>
          <a href="#services" className="hover:text-indigo-400 transition-colors">Services</a>
          <a href="#portfolio" className="hover:text-indigo-400 transition-colors">Portfolio</a>
          <a href="#contact" className="hover:text-indigo-400 transition-colors">Contact</a>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="accueil" className="min-h-screen flex items-center justify-center">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-6xl font-extrabold bg-gradient-to-r from-indigo-400 via-purple-400 to-green-400 bg-clip-text text-transparent">
            Bienvenue chez WorldCreation
          </h1>
          <p className="text-3xl font-semibold mb-6 text-gray-300">Transformez vos idées en sites web exceptionnels avec WorldCreation</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-6">
            <button className="bg-gradient-to-r from-indigo-500 to-purple-500 px-6 py-4 rounded-full font-semibold hover:shadow-lg transition-all">
              Voir nos réalisations
            </button>
            <button className="border-2 border-indigo-500 px-6 py-4 rounded-full font-semibold hover:bg-indigo-500 transition-all">
              Démarrer un projet
            </button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-12">Nos Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: "Sites Web", icon: "🌐", desc: "Sites modernes et élégants", price: "À partir de 800€" },
              { title: "Applications", icon: "📱", desc: "Solutions sur mesure", price: "Sur devis" },
              { title: "E-commerce", icon: "🛒", desc: "Boutiques complètes", price: "À partir de 1200€" }
            ].map((service, index) => (
              <div key={index} className="bg-gray-700 p-6 rounded-xl shadow-md hover:transform hover:scale-105 transition-all">
                <div className="text-5xl">{service.icon}</div>
                <h3 className="text-xl font-semibold mt-4">{service.title}</h3>
                <p className="text-gray-400 mt-2">{service.desc}</p>
                <p className="text-indigo-400 font-semibold mt-4">{service.price}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-12">Portfolio</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: "Restaurant Le Gourmet", icon: "🍽️", desc: "Restaurant gastronomique élégant" },
              { title: "Wise Nomad", icon: "🌍", desc: "Boutique de vêtements moderne" },
              { title: "Fast Code", icon: "💻", desc: "Agence digitale dynamique" },
              { title: "Luxury Estate", icon: "🏠", desc: "Agence immobilière de luxe" },
              { title: "ProConsult", icon: "📊", desc: "Cabinet de conseil stratégique" },
              { title: "WorkStation", icon: "📂", desc: "Logiciel de gestion professionnelle" }
            ].map((project, index) => (
              <div key={index} className="bg-gray-800 p-6 rounded-xl shadow-md hover:transform hover:scale-105 transition-all">
                <div className="text-5xl">{project.icon}</div>
                <h3 className="text-xl font-semibold mt-4">{project.title}</h3>
                <p className="text-gray-400 mt-2">{project.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default WorldCreationApp;